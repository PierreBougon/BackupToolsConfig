#parse("C File Header.h")
#[[#ifndef]]# ${INCLUDE_GUARD}_
#[[#define]]# ${INCLUDE_GUARD}_

${NAMESPACES_OPEN}

class ${NAME} {

};

${NAMESPACES_CLOSE}

#[[#endif]]# // !${INCLUDE_GUARD}_
