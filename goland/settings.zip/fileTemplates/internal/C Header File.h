#parse("C File Header.h")
#[[#ifndef]]# ${INCLUDE_GUARD}_
#[[#define]]# ${INCLUDE_GUARD}_

#[[#endif]]# // !${INCLUDE_GUARD}_
